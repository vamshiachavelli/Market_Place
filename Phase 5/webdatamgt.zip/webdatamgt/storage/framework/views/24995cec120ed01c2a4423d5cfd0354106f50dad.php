<main id="main" class="main-site">
<div class="container">
<?php if(session()->has('message')): ?>
        <div class="alert alert-success"><?php echo e(session('message')); ?></div>
    <?php endif; ?>
    <div class="panel panel-default" style="margin-top:20px;">
        <div class="panel-heading">
            <h1>List of Adverts
            <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#addClubModal">
                Add New Advert
            </button>
            </h1>
        </div>
        <div class="panel-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Advert Title</th>
                        <th>Date Posted</th>
                        <th>Posted By</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $adverts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($advert->advertTitle); ?></td>
                    <td><?php echo e($advert->datePosted); ?></td>
                    <td><?php echo e($advert->postedBy); ?></td>
                    <td><a href="#" data-toggle="modal" data-target="#updateAdvertModal" wire:click.prevent="edit(<?php echo e($advert->id); ?>)"><i class="fa fa-edit"></i></a> | <a href="#" wire:click.prevent="delete(<?php echo e($advert->id); ?>)"><i class="fa fa-trash"></i></a></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

</div>
</div><?php /**PATH C:\xampp\htdocs\webdatamgt\resources\views/livewire/student/adverts.blade.php ENDPATH**/ ?>