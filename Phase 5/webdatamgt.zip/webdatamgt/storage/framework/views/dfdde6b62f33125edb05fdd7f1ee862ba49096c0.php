<main id="main">
		<div class="container">

			<!--MAIN SLIDE-->
			<!--Product Categories-->
			<div class="wrap-show-advance-info-box style-1">
				<h3 class="title-box">Welcome</h3>
				<div class="wrap-top-banner">
					<a href="#" class="link-banner banner-effect-2">
						<figure><img src="<?php echo e(asset('assets/images/fashion-accesories-banner.jpg')); ?>" width="1170" height="240" alt=""></figure>
					</a>
				</div>
				<div class="wrap-products">
					<div class="wrap-product-tab tab-style-1">
						
						<div class="tab-contents">

							<div class="tab-content-item active" id="fashion_1a">
								<div class="wrap-products slide-carousel owl-carousel style-nav-1 equal-container" data-items="5" data-loop="false" data-nav="true" data-dots="false" data-responsive='{"0":{"items":"1"},"480":{"items":"2"},"768":{"items":"3"},"992":{"items":"4"},"1200":{"items":"5"}}' >

									<div class="product product-style-2 equal-elem ">
									<div class="product-thumnail" style="height:180px;">
										
									</div>
							
								</div>


								</div>
							</div>

							<!-- tab content was here before -->

						</div>
					</div>
				</div>
			</div>			

		</div>

	</main>
<?php /**PATH C:\xampp\htdocs\webdatamgt\resources\views/livewire/home-component.blade.php ENDPATH**/ ?>