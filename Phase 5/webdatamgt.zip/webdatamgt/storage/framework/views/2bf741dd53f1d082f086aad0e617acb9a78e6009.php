
<main id="main" class="main-site">
<?php echo $__env->make('livewire.businessowner.stdcreate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('livewire.businessowner.stdupdate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <?php if(session()->has('message')): ?>
        <div class="alert alert-success"><?php echo e(session('message')); ?></div>
    <?php endif; ?>
    <div class="panel panel-default" style="margin-top:20px;">
    <div class="panel-heading">
            <h1>
                List of Students
                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#addStudentModal">
                Add New Student
            </button>
            </h1>
           
    </div>
        <div class="panel-body">
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Firstname</th>
                    <th>Lastname</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($student->firstname); ?></td>
                        <td><?php echo e($student->lastname); ?></td>
                        <td><?php echo e($student->email); ?></td>
                        <td><?php echo e($student->phone); ?></td>
                        <td><a href="#" data-toggle="modal" data-target="#updateStudentModal" wire:click.prevent="edit(<?php echo e($student->id); ?>)"><i class="fa fa-edit"></i></a> | <a href="#" wire:click.prevent="delete(<?php echo e($student->id); ?>)"><i class="fa fa-trash"></i></a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                </tbody>
            </table>
        </div>
    </div>

</div>
</div><?php /**PATH C:\xampp\htdocs\webdatamgt\resources\views/livewire/businessowner/students.blade.php ENDPATH**/ ?>