
<main id="main" class="main-site">
<div class="container">
<?php if(session()->has('message')): ?>
        <div class="alert alert-success"><?php echo e(session('message')); ?></div>
    <?php endif; ?>
    <div class="panel panel-default" style="margin-top:20px;">
    <div class="panel-heading">
            <h1>
                List of Clubs
                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#addClubModal">
                Add New Club
            </button>
            </h1>
           
    </div>
        <div class="panel-body">
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Activity Name</th>
                    <th>Description</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $clubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $club): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($club->activityName); ?></td>
                        <td><?php echo e($club->activityDesc); ?></td>
                        <td><?php echo e($club->actvityStartDate); ?></td>
                        <td><?php echo e($club->actvityEndDate); ?></td>
                        <td><a href="#" data-toggle="modal" data-target="#updateClubModal" wire:click.prevent="edit(<?php echo e($club->id); ?>)"><i class="fa fa-edit"></i></a> | <a href="#" wire:click.prevent="delete(<?php echo e($club->id); ?>)"><i class="fa fa-trash"></i></a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                </tbody>
            </table>
        </div>
    </div>

</div>
</div><?php /**PATH C:\xampp\htdocs\webdatamgt\resources\views/livewire/student/clubs.blade.php ENDPATH**/ ?>