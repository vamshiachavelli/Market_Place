<?php

namespace App\Http\Livewire\Businessowner;

use Livewire\Component;

class BowDashboardComponent extends Component
{
    public function render()
    {
        return view('livewire.businessowner.bow-dashboard-component')->layout('layouts.base');
    }
}
