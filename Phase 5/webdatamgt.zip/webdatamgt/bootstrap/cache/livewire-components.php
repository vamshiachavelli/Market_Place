<?php return array (
  'businessowner.bow-dashboard-component' => 'App\\Http\\Livewire\\Businessowner\\BowDashboardComponent',
  'businessowner.students' => 'App\\Http\\Livewire\\Businessowner\\Students',
  'cart-component' => 'App\\Http\\Livewire\\CartComponent',
  'checkout-component' => 'App\\Http\\Livewire\\CheckoutComponent',
  'home-component' => 'App\\Http\\Livewire\\HomeComponent',
  'schooladmin.sadm-dashboard-component' => 'App\\Http\\Livewire\\Schooladmin\\SadmDashboardComponent',
  'shop-component' => 'App\\Http\\Livewire\\ShopComponent',
  'student.adverts' => 'App\\Http\\Livewire\\Student\\Adverts',
  'student.clubs' => 'App\\Http\\Livewire\\Student\\Clubs',
  'student.products' => 'App\\Http\\Livewire\\Student\\Products',
  'student.std-dashboard-component' => 'App\\Http\\Livewire\\Student\\StdDashboardComponent',
  'superadmin.sa-dashboard-component' => 'App\\Http\\Livewire\\Superadmin\\SaDashboardComponent',
);